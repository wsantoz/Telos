package financas;

import financas.modelo.Lancamento;
import financas.modelo.TipoLancamento;
import financas.servico.GerenciadorLancamentos;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

/** Menu de console (versão inicial do núcleo do sistema). */
public class Main {

    private static final DateTimeFormatter FORMATO_DATA = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private static final Locale PT_BR = Locale.forLanguageTag("pt-BR");

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        GerenciadorLancamentos gerenciador = new GerenciadorLancamentos();
        int opcao = -1;

        while (opcao != 0) {
            exibirMenu();
            opcao = lerInteiro(teclado, "Escolha uma opção: ");

            switch (opcao) {
                case 1 -> cadastrar(teclado, gerenciador);
                case 2 -> listar(gerenciador.listarTodos());
                case 3 -> buscar(teclado, gerenciador);
                case 4 -> remover(teclado, gerenciador);
                case 5 -> mostrarSaldo(gerenciador);
                case 0 -> System.out.println("Até logo!");
                default -> System.out.println("Opção inválida. Tente novamente.");
            }
        }
        teclado.close();
    }

    private static void exibirMenu() {
        System.out.println();
        System.out.println("===== GESTOR FINANCEIRO =====");
        System.out.println("1 - Cadastrar lançamento");
        System.out.println("2 - Listar lançamentos");
        System.out.println("3 - Buscar por categoria");
        System.out.println("4 - Remover lançamento");
        System.out.println("5 - Ver saldo");
        System.out.println("0 - Sair");
    }

    private static void cadastrar(Scanner teclado, GerenciadorLancamentos gerenciador) {
        System.out.println("-- Novo lançamento --");
        int escolhaTipo = lerInteiro(teclado, "Tipo (1 = Receita, 2 = Despesa): ");
        if (escolhaTipo != 1 && escolhaTipo != 2) {
            System.out.println("Tipo inválido.");
            return;
        }
        TipoLancamento tipo = (escolhaTipo == 1) ? TipoLancamento.RECEITA : TipoLancamento.DESPESA;

        double valor = lerDecimal(teclado, "Valor (ex.: 49,90): ");
        System.out.print("Categoria: ");
        String categoria = teclado.nextLine();
        System.out.print("Descrição: ");
        String descricao = teclado.nextLine();
        LocalDate data = lerData(teclado, "Data (dd/mm/aaaa): ");

        try {
            Lancamento criado = gerenciador.adicionar(tipo, valor, categoria, descricao, data);
            System.out.println("Cadastrado com sucesso: " + criado);
        } catch (IllegalArgumentException e) {
            System.out.println("Não foi possível cadastrar: " + e.getMessage());
        }
    }

    private static void listar(List<Lancamento> lista) {
        if (lista.isEmpty()) {
            System.out.println("Nenhum lançamento cadastrado.");
            return;
        }
        for (Lancamento l : lista) {
            System.out.println(l);
        }
    }

    private static void buscar(Scanner teclado, GerenciadorLancamentos gerenciador) {
        System.out.print("Categoria: ");
        String categoria = teclado.nextLine();
        List<Lancamento> encontrados = gerenciador.buscarPorCategoria(categoria);
        if (encontrados.isEmpty()) {
            System.out.println("Nada encontrado nessa categoria.");
        } else {
            listar(encontrados);
        }
    }

    private static void remover(Scanner teclado, GerenciadorLancamentos gerenciador) {
        int id = lerInteiro(teclado, "ID do lançamento a remover: ");
        if (gerenciador.remover(id)) {
            System.out.println("Lançamento removido.");
        } else {
            System.out.println("ID não encontrado.");
        }
    }

    private static void mostrarSaldo(GerenciadorLancamentos gerenciador) {
        double receitas = gerenciador.totalPorTipo(TipoLancamento.RECEITA);
        double despesas = gerenciador.totalPorTipo(TipoLancamento.DESPESA);
        System.out.println(String.format(PT_BR, "Receitas: R$ %.2f", receitas));
        System.out.println(String.format(PT_BR, "Despesas: R$ %.2f", despesas));
        System.out.println(String.format(PT_BR, "Saldo:    R$ %.2f", gerenciador.calcularSaldo()));
    }

    // ---------- Leitura segura (nunca deixa o programa quebrar com entrada inválida) ----------

    private static int lerInteiro(Scanner teclado, String mensagem) {
        while (true) {
            System.out.print(mensagem);
            String texto = teclado.nextLine().trim();
            try {
                return Integer.parseInt(texto);
            } catch (NumberFormatException e) {
                System.out.println("Digite um número inteiro válido.");
            }
        }
    }

    private static double lerDecimal(Scanner teclado, String mensagem) {
        while (true) {
            System.out.print(mensagem);
            String texto = teclado.nextLine().trim().replace(",", ".");
            try {
                return Double.parseDouble(texto);
            } catch (NumberFormatException e) {
                System.out.println("Digite um valor numérico válido (ex.: 49,90).");
            }
        }
    }

    private static LocalDate lerData(Scanner teclado, String mensagem) {
        while (true) {
            System.out.print(mensagem);
            String texto = teclado.nextLine().trim();
            try {
                return LocalDate.parse(texto, FORMATO_DATA);
            } catch (DateTimeParseException e) {
                System.out.println("Data inválida. Use o formato dd/mm/aaaa.");
            }
        }
    }
}
