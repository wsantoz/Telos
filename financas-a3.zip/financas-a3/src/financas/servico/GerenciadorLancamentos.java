package financas.servico;

import financas.modelo.Lancamento;
import financas.modelo.TipoLancamento;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/** Regras de negócio dos lançamentos. Aqui fica a lógica; o menu apenas conversa com o usuário. */
public class GerenciadorLancamentos {

    private final List<Lancamento> lancamentos = new ArrayList<>();
    private int proximoId = 1;

    public Lancamento adicionar(TipoLancamento tipo, double valor, String categoria,
                                String descricao, LocalDate data) {
        Lancamento novo = new Lancamento(proximoId, tipo, valor, categoria, descricao, data);
        lancamentos.add(novo);
        proximoId++;
        return novo;
    }

    public List<Lancamento> listarTodos() {
        return new ArrayList<>(lancamentos); // cópia, para ninguém alterar a lista original
    }

    public List<Lancamento> buscarPorCategoria(String categoria) {
        List<Lancamento> resultado = new ArrayList<>();
        for (Lancamento l : lancamentos) {
            if (l.getCategoria().equalsIgnoreCase(categoria.trim())) {
                resultado.add(l);
            }
        }
        return resultado;
    }

    public boolean remover(int id) {
        for (int i = 0; i < lancamentos.size(); i++) {
            if (lancamentos.get(i).getId() == id) {
                lancamentos.remove(i);
                return true;
            }
        }
        return false;
    }

    public double totalPorTipo(TipoLancamento tipo) {
        double total = 0;
        for (Lancamento l : lancamentos) {
            if (l.getTipo() == tipo) {
                total += l.getValor();
            }
        }
        return total;
    }

    public double calcularSaldo() {
        return totalPorTipo(TipoLancamento.RECEITA) - totalPorTipo(TipoLancamento.DESPESA);
    }
}
