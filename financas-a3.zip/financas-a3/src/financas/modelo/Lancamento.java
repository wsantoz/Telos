package financas.modelo;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/** Representa uma receita ou despesa registrada pelo usuário. */
public class Lancamento {

    private static final DateTimeFormatter FORMATO_DATA = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private final int id;
    private final TipoLancamento tipo;
    private final double valor;
    private final String categoria;
    private final String descricao;
    private final LocalDate data;

    public Lancamento(int id, TipoLancamento tipo, double valor, String categoria,
                      String descricao, LocalDate data) {
        // Validações: o objeto nunca é criado em estado inválido.
        if (tipo == null) {
            throw new IllegalArgumentException("O tipo do lançamento é obrigatório.");
        }
        if (valor <= 0) {
            throw new IllegalArgumentException("O valor deve ser maior que zero.");
        }
        if (categoria == null || categoria.isBlank()) {
            throw new IllegalArgumentException("A categoria é obrigatória.");
        }
        if (descricao == null || descricao.isBlank()) {
            throw new IllegalArgumentException("A descrição é obrigatória.");
        }
        if (data == null) {
            throw new IllegalArgumentException("A data é obrigatória.");
        }
        this.id = id;
        this.tipo = tipo;
        this.valor = valor;
        this.categoria = categoria.trim();
        this.descricao = descricao.trim();
        this.data = data;
    }

    public int getId() { return id; }
    public TipoLancamento getTipo() { return tipo; }
    public double getValor() { return valor; }
    public String getCategoria() { return categoria; }
    public String getDescricao() { return descricao; }
    public LocalDate getData() { return data; }

    @Override
    public String toString() {
        String sinal = (tipo == TipoLancamento.RECEITA) ? "+" : "-";
        return String.format(Locale.forLanguageTag("pt-BR"),
                "#%d | %s | %-8s | %-15s | %s R$ %.2f | %s",
                id, data.format(FORMATO_DATA), tipo, categoria, sinal, valor, descricao);
    }
}
