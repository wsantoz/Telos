package financas.modelo;

/** Tipo de um lançamento financeiro. */
public enum TipoLancamento {
    RECEITA,
    DESPESA
}
