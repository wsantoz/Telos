# Gestor Financeiro — Projeto A3 (núcleo em Java)

Versão inicial do núcleo: cadastro, listagem, busca por categoria, remoção e saldo, tudo em console.

## Como executar

Requisito: JDK 17 ou superior (`javac -version` para conferir).

```bash
# dentro da pasta do projeto
mkdir out
javac -d out $(find src -name "*.java")     # Linux/Mac
java -cp out financas.Main
```

No Windows (PowerShell):

```powershell
mkdir out
javac -d out (Get-ChildItem -Recurse src -Filter *.java).FullName
java -cp out financas.Main
```

Ou abra a pasta no IntelliJ IDEA / VS Code e execute a classe `financas.Main`.

## Estrutura

- `modelo/` — as "coisas" do sistema (Lancamento, TipoLancamento). Validam seus próprios dados.
- `servico/` — regras de negócio (GerenciadorLancamentos). É aqui que o score e os simuladores vão morar.
- `Main.java` — menu de console; só lê dados e mostra resultados.

## Próximos passos (semana 2)

- [ ] Classe `Categoria` e orçamento mensal por categoria
- [ ] Editar lançamento
- [ ] Salvar/carregar em arquivo (CSV)
- [ ] Relatório do mês
- [ ] Testes (casos válidos e inválidos)

Observação: o projeto usa `double` por simplicidade. Se a professora já tiver ensinado `BigDecimal`, vale migrar os valores monetários depois.
